#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "Serial.h"
#include "Key.h"

uint8_t KeyNum;	//定义用于接收按键键码的变量












int main(void)
{
    /*模块初始化*/
    OLED_Init();		// OLED初始化
    Key_Init();			// 按键初始化
    Serial_Init();		// UART1初始化
    UART2_Init();		// UART2初始化
    UART3_Init();		// UART3初始化
    UART4_Init();		// UART4初始化
    
    /*显示静态字符串*/
    //OLED_ShowString(1, 1, "TxPacket");
    //OLED_ShowString(3, 1, "RxPacket");
   
    /*设置发送数据包数组的初始值，用于测试*/
    Serial_TxPacket[0] = 0x00;
    Serial_TxPacket[1] = 0xA2;
    Serial_TxPacket[2] = 0xA4;
    
    while (1)
    {  
        // 串口发送数据包
        Serial_SendPacket();		// UART1发送
        
        // 处理所有接收通道
        uint32_t total_weight = 0;
        
        // 处理UART1数据
        if (Serial_GetRxFlag())
        {
            total_weight += (Serial_RxPacket[4] * 65536 + Serial_RxPacket[5] * 256 + Serial_RxPacket[6]) / 100;
        }
        
        // 处理UART2数据
        if (Serial_GetRxFlag2())
        {
            total_weight += (Serial_RxPacket2[4] * 65536 + Serial_RxPacket2[5] * 256 + Serial_RxPacket2[6]) / 100;
        }
        
        // 处理UART3数据
        if (Serial_GetRxFlag3())
        {
            total_weight += (Serial_RxPacket3[4] * 65536 + Serial_RxPacket3[5] * 256 + Serial_RxPacket3[6]) / 100;
        }
        
        // 处理UART4数据
        if (Serial_GetRxFlag4())
        {
            total_weight += (Serial_RxPacket4[4] * 65536 + Serial_RxPacket4[5] * 256 + Serial_RxPacket4[6]) / 100;
        }
        
        // 显示所有接收数据
        OLED_ShowHexNum(1, 1, Serial_TxPacket[0], 2);
        OLED_ShowHexNum(1, 4, Serial_TxPacket[1], 2);
        OLED_ShowHexNum(1, 7, Serial_TxPacket[2], 2);
        
        OLED_ShowHexNum(2, 1, Serial_RxPacket2[0], 2);
        OLED_ShowHexNum(2, 4, Serial_RxPacket2[1], 2);
        OLED_ShowHexNum(2, 7, Serial_RxPacket2[2], 2);
        OLED_ShowHexNum(2, 10, Serial_RxPacket2[3], 2);
        OLED_ShowHexNum(3, 1, Serial_RxPacket2[4], 2);
        OLED_ShowHexNum(3, 4, Serial_RxPacket2[5], 2);
        OLED_ShowHexNum(3, 7, Serial_RxPacket2[6], 2);
        OLED_ShowHexNum(3, 10, Serial_RxPacket2[7], 2);

        
        // 显示总重量
        OLED_ShowNum(4, 1, total_weight, 6);
        OLED_ShowString(4, 7, "g");
        //Delay_s(1);
		//Serial_SendNumber2(total_weight, 6);
		float weight=total_weight;
		Serial_Printf2("Weight: %.1f g\n", weight/10.0);
		Serial_SendByte2('\r');         // 添加回车符
         Serial_SendByte2('\n'); 	// 添加换行符
		Delay_ms(500);
    }
}
