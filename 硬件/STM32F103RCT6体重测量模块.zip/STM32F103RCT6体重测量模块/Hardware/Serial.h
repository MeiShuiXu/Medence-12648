#ifndef __SERIAL_H
#define __SERIAL_H

#include <stdio.h>

extern uint8_t Serial_TxPacket[];
extern uint8_t Serial_RxPacket[];

extern uint8_t Serial_RxPacket2[];
extern uint8_t Serial_RxPacket3[];
extern uint8_t Serial_RxPacket4[];
extern uint8_t Serial_RxFlag2;
extern uint8_t Serial_RxFlag3;
extern uint8_t Serial_RxFlag4;

void Serial_Init(void);
void Serial_SendByte(uint8_t Byte);
void Serial_SendArray(uint8_t *Array, uint16_t Length);
void Serial_SendString(char *String);
void Serial_SendNumber(uint32_t Number, uint8_t Length);
void Serial_Printf(char *format, ...);

void Serial_SendPacket(void);
uint8_t Serial_GetRxFlag(void);



void Serial_SendNumber2(uint32_t Number, uint8_t Length);
void Serial_SendByte2(uint8_t Byte);
// 添加的UART2相关声明
void UART2_Init(void);		// UART2初始化函数声明
void Serial_SendString2(char *String);
void Serial_Printf2(char *format, ...);
uint8_t Serial_GetRxFlag2(void);	// UART2接收标志位获取函数

// 添加的UART3相关声明
void UART3_Init(void);		// UART3初始化函数声明
uint8_t Serial_GetRxFlag3(void);	// UART3接收标志位获取函数

// 添加的UART4相关声明
void UART4_Init(void);		// UART4初始化函数声明
uint8_t Serial_GetRxFlag4(void);	// UART4接收标志位获取函数
#endif
